# Journey OS — Canonical Decisions Reference
# All 45 resolved production findings + architectural decisions
# Source of truth: tests/fixtures/journey-os-production-bible.html

## Three-Hub Invariant (D06)
SubConcept (knowledge) + SLO (pedagogy) + USMLE_Subtopic (assessment)
All three required before AssessmentItem enters practice pool.

## Evidence Grade Weights (G06)
A = 1.00 (faculty confirmed)
B = 0.82 (UMLS verified, post-P2)
C = 0.65 (cold-start, post-P1)
D = 0.45 (historical/unverified)
path_confidence = product of edge weights along traversal path

## Chunk Size (D04)
Canonical: 150-250 tokens, 30-token overlap, entity-boundary-aligned
Never: 50-600 ranges, zero overlap, arbitrary splits

## Model Routing (D05)
Sonnet 4 (claude-sonnet-4-20250514): core generation + critique gate
Haiku 4.5 (claude-haiku-4-5-20251001): HyDE, distractors, rationale, QA, LOD, classify, OCR
Cost target: $0.12/item

## LOD Brief Storage (G05)
SubConcept.lod_brief_id = UUID FK (8 bytes in Neo4j)
LOD brief text → subconcept_lod_briefs Supabase table
Expiry: 180 days (lod_brief_version + expires_at)

## Dual-Write Order (G08)
Supabase FIRST. Neo4j SECOND. Never block on Neo4j failure.
neo4j_synced_at + neo4j_sync_status on all dual-write tables.

## SLO Direction (D09)
SLO -[:CONTRIBUTES_TO]→ ILO  (child → parent — NEVER reverse)

## GROUNDED_IN Scope (D03)
LOD links ONLY: SubConcept → StandardTerm, SyllabusTopic → StandardTerm
Not for: AssessmentItem (use SOURCED_FROM), Lecture (use TEACHES chain)

## CoverageRecord (D02)
Progressive: created after FIRST approved item
coverage_score = min(assessment_count, 3) / 3.0 (capped at 1.0)
Updates: atomic SET only (never read-modify-write)

## Inngest Infrastructure (G13)
Inngest ONLY (not Kafka). 14 events, journey/ namespace.
Three main functions: journey/lecture.process, journey/subconcept.enrich, journey/items.batch-generate

## Critical C01-C10 Resolutions
C01: session_answers table — auto-save on every answer selection
C02: Time-windowed RLS on assessment_items — active session only
C03: Atomic CoverageRecord — SET count = count + 1 (never read-modify-write)
C04: Dead letter queue — onFailure handlers write to pipeline_dead_letters
C05: neo4jQuery wrapper — ESLint enforces, no raw driver ever
C06: Model pinning — startup check validates model version
C07: LOD brief versioning — 180-day expiry, quarterly regen
C08: P1 orphan cleanup — onFailure removes partial graph state
C09: SAME_AS cycle prevention — createSameAsIfSafe() always
C10: Three-layer generation rate control — concurrent + confirm + daily quota
